SELECT
    o.order_id,
    r.review_score,
    NULLIF(o.order_delivered_customer_date, '')::date AS actual_delivery_date,
    NULLIF(o.order_estimated_delivery_date, '')::date AS estimated_delivery_date,
    CASE
        WHEN NULLIF(o.order_delivered_customer_date, '')::date > NULLIF(o.order_estimated_delivery_date, '')::date THEN 'Delayed'
        ELSE 'On Time'
    END AS delivery_status
FROM 
    public.olist_orders_dataset o
JOIN 
    public.olist_order_reviews_dataset r ON o.order_id = r.order_id
WHERE 
    o.order_status = 'delivered'
    AND NULLIF(o.order_delivered_customer_date, '') IS NOT NULL
    AND NULLIF(o.order_estimated_delivery_date, '') IS NOT NULL;