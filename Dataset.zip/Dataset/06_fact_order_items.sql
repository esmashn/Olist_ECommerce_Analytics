SELECT
    oi.order_id,
    o.customer_id,
    oi.seller_id,
    oi.product_id,
    NULLIF(o.order_purchase_timestamp, '')::timestamp AS order_purchase_date,
    oi.price,
    oi.freight_value
FROM 
    public.olist_order_items_dataset oi
JOIN 
    public.olist_orders_dataset o ON oi.order_id = o.order_id
WHERE 
    o.order_status NOT IN ('canceled', 'unavailable');