SELECT 
    EXTRACT(HOUR FROM order_purchase_timestamp::timestamp) AS order_hour,
    COUNT(order_id) AS total_orders
FROM 
    public.olist_orders_dataset
WHERE 
    order_status = 'delivered'
GROUP BY 
    order_hour
ORDER BY 
    total_orders DESC;