SELECT
    order_id,
    payment_type,
    payment_installments,
    payment_value
FROM 
    public.olist_order_payments_dataset
WHERE 
    payment_type != 'not_defined';