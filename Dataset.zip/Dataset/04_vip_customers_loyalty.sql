SELECT 
    c.customer_unique_id,
    SUM(oi.price) AS total_spent,
    COUNT(DISTINCT o.order_id) AS total_orders
FROM 
    public.olist_customers_dataset c
JOIN 
    public.olist_orders_dataset o ON c.customer_id = o.customer_id
JOIN 
    public.olist_order_items_dataset oi ON oi.order_id = o.order_id
WHERE 
    o.order_status = 'delivered'
GROUP BY 
    c.customer_unique_id
ORDER BY 
    total_spent DESC
LIMIT 10;