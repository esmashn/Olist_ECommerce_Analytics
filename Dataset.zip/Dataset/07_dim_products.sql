SELECT
    p.product_id,
    COALESCE(pc.product_category_name_english, 'Unknown') AS product_category_name_english
FROM 
    public.olist_products_dataset p
LEFT JOIN 
    public.product_category_name_translation pc ON p.product_category_name = pc.product_category_name;