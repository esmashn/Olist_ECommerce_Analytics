WITH Delivery_Analysis as (
    SELECT
        o.order_id,
        NULLIF(o.order_estimated_delivery_date, '')::date AS estimated_delivery_date,
        NULLIF(o.order_delivered_customer_date, '')::date AS actual_date,
        r.review_score,
        CASE
            WHEN NULLIF(o.order_delivered_customer_date, '')::date > NULLIF(o.order_estimated_delivery_date, '')::date then'Delayed'
            ELSE 'On Time'
        END AS delivery_status
    FROM 
        public.olist_orders_dataset o
    JOIN 
        public.olist_order_reviews_dataset r ON o.order_id = r.order_id
    WHERE 
        o.order_status = 'delivered'
        AND NULLIF(o.order_delivered_customer_date, '') IS NOT NULL
        AND NULLIF(o.order_estimated_delivery_date, '') IS NOT NULL
)
SELECT 
    delivery_status AS "Delivery Status",
    COUNT(order_id) AS "Number of Orders",
    ROUND(AVG(review_score), 2) as "Average Review Score (1-5)"
FROM 
    Delivery_Analysis
GROUP BY 
    delivery_status
ORDER BY 
    "Number of Orders" DESC;