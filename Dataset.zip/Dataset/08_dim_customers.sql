SELECT
    customer_id,
    customer_city,
    customer_state
FROM 
    public.olist_customers_dataset;