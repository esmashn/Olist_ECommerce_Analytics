with Seller_Revenue as (
    SELECT
        s.seller_state,
        s.seller_id,
        sum(oi.price) as total_revenue
        FROM
        public.olist_orders_dataset o
        JOIN
        public.olist_order_items_dataset oi on o.order_id=oi.order_id
        JOIN
        public.olist_sellers_dataset s on oi.seller_id=s.seller_id
        WHERE
        o.order_status='delivered'
        group by
        s.seller_state,
        s.seller_id

)

select 
seller_state as "STATE",
seller_id AS "SELLER ID",
total_revenue AS "TOTAL REVENUE",
RANK() OVER(PARTITION BY seller_state order by total_revenue DESC) as state_rank
FROM
Seller_Revenue
ORDER BY 
total_revenue DESC;