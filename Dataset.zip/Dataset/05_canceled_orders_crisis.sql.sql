SELECT 
    c.customer_state AS state,
    COUNT(o.order_id) AS canceled_orders
FROM 
    public.olist_orders_dataset o
JOIN 
    public.olist_customers_dataset c ON o.customer_id = c.customer_id
WHERE 
    o.order_status = 'canceled'
GROUP BY 
    c.customer_state
ORDER BY 
    canceled_orders DESC
LIMIT 3;